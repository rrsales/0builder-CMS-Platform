// HN core menu library
window.HN = window.HN || {};
