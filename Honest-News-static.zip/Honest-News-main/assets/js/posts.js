// posts.js — Blog post system placeholder

const POSTS = [
  {
    id: 1,
    title: "Welcome to Honest News",
    excerpt: "Biblical truth, prophetic insight, and real journalism.",
    url: "post1.html"
  }
];

console.log("Posts loaded:", POSTS);