<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Honest News – Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Protect dashboard -->
  <script>
    if (localStorage.getItem("hn_logged") !== "yes") {
      location.href = "admin.html";
    }
  </script>

  <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root{
      --bg:#020617;
      --panel-bg:#0f172a;
      --accent:#0ea5e9;
      --border:#1e293b;
      --text:#e2e8f0;
      --radius:1rem;
    }

    body{
      margin:0;
      font-family:system-ui,-apple-system,BlinkMacSystemFont,"SF Pro Text","Segoe UI",sans-serif;
      background:var(--bg);
      color:var(--text);
      display:flex;
      height:100vh;
      overflow:hidden;
    }

    /* layout panels */
    #leftPanel,#rightPanel{
      background:var(--panel-bg);
      border-right:1px solid var(--border);
      width:260px;
      display:flex;
      flex-direction:column;
      transition:transform 0.3s ease;
      overflow-y:auto;
    }
    #rightPanel{
      border-right:none;
      border-left:1px solid var(--border);
    }

    #canvas{
      flex:1;
      background:#0b1120;
      display:flex;
      flex-direction:column;
      overflow:hidden;
      position:relative;
    }

    header{
      background:rgba(15,23,42,0.95);
      backdrop-filter:blur(10px);
      border-bottom:1px solid var(--border);
      padding:.75rem 1rem;
      display:flex;
      align-items:center;
      justify-content:space-between;
    }

    header h1{
      font-size:1.1rem;
      margin:0;
      color:var(--accent);
    }

    header button{
      background:none;
      border:none;
      color:var(--text);
      font-size:1.2rem;
      cursor:pointer;
    }

    @media(max-width:900px){
      #leftPanel{transform:translateX(-100%);}
      #leftPanel.show{transform:translateX(0);}
      #rightPanel{transform:translateX(100%);}
      #rightPanel.show{transform:translateX(0);}
    }
  </style>
</head>

<body>
  <!-- LEFT PANEL – Pages & Menu -->
  <aside id="leftPanel">
    <div id="pagesPanel"></div>
    <div id="menuPanel"></div>
  </aside>

  <!-- MAIN CANVAS -->
  <main id="canvas">
    <header>
      <button id="toggleLeft"><i class="fa fa-bars"></i></button>
      <h1>Honest News CMS</h1>
      <button id="toggleRight"><i class="fa fa-sliders-h"></i></button>
    </header>

    <section id="canvasContent">
      <!-- Content dynamically loaded from modules -->
    </section>
  </main>

  <!-- RIGHT PANEL – Inspector & Text Editor -->
  <aside id="rightPanel">
    <div id="inspectorPanel"></div>
    <div id="textEditorPanel"></div>
  </aside>

  <!-- MODULE SCRIPTS -->
  <script type="module" src="modules/pages.js"></script>
  <script type="module" src="modules/menu.js"></script>
  <script type="module" src="modules/inspector.js"></script>
  <script type="module" src="modules/canvas.js"></script>
  <script type="module" src="modules/containers.js"></script>
  <script type="module" src="modules/textEditor.js"></script>
  <script type="module" src="modules/main.js"></script>
</body>
</html>
