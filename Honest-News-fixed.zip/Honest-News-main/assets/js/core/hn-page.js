// HN core page renderer
window.HN = window.HN || {};
