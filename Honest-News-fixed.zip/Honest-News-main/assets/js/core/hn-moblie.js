// HN core mobile nav
window.HN = window.HN || {};
